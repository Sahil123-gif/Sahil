// Initialize EmailJS
emailjs.init("your_emailjs_public_key"); // Replace with actual key

// Application State
let appState = {
    sensorData: {
        waterLevel: { current: 75, unit: "%", status: "normal", threshold: { min: 20, max: 90 } },
        temperature: { current: 32, unit: "°C", status: "normal", threshold: { min: 15, max: 45 } },
        flowRate: { current: 250, unit: "L/min", status: "normal", threshold: { min: 100, max: 400 } },
        rainSensor: { current: false, status: "normal" },
        pH: { current: 7.2, unit: "pH", status: "normal", threshold: { min: 6.5, max: 8.5 } }
    },
    powerData: {
        solar: { current: 1200, daily: 8500, unit: "W", status: "normal" },
        battery: { percentage: 85, voltage: 12.4, current: -5.2, status: "charging" },
        generator: { status: "standby", fuelLevel: 75, runtime: 0 }
    },
    pumpStatus: {
        mode: "auto",
        running: true,
        uptime: "2d 14h 32m",
        totalRuntime: "156h 45m"
    },
    alerts: [
        { id: 1, type: "warning", message: "Water level approaching maximum threshold", timestamp: new Date().toISOString(), active: true },
        { id: 2, type: "info", message: "Solar charging efficiency optimal", timestamp: new Date().toISOString(), active: true }
    ],
    historicalData: {
        waterLevel: [],
        temperature: [],
        flowRate: [],
        solarPower: [],
        timestamps: []
    },
    activeTab: "dashboard",
    powerSource: "auto",
    emailSettings: {
        address: "",
        criticalAlerts: true,
        warnings: true,
        infoMessages: false
    }
};

// Chart instances
let liveChart = null;
let sensorChart = null;

// DOM Elements
const elements = {};

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    initializeElements();
    initializeEventListeners();
    initializeCharts();
    startDataSimulation();
    updateUI();
    updateTimestamp();
    
    // Update timestamp every second
    setInterval(updateTimestamp, 1000);
    
    // Update sensor data every 5 seconds
    setInterval(simulateRealTimeData, 5000);
    
    // Update UI every second
    setInterval(updateUI, 1000);
});

function initializeElements() {
    // Cache DOM elements
    elements.navTabs = document.querySelectorAll('.nav-tab');
    elements.tabContents = document.querySelectorAll('.tab-content');
    elements.currentTime = document.getElementById('currentTime');
    elements.systemStatus = document.getElementById('systemStatus');
    
    // Dashboard elements
    elements.pumpStatusIndicator = document.getElementById('pumpStatusIndicator');
    elements.pumpStatusText = document.getElementById('pumpStatusText');
    elements.pumpUptime = document.getElementById('pumpUptime');
    elements.pumpTotalRuntime = document.getElementById('pumpTotalRuntime');
    
    // Metric values
    elements.waterLevelValue = document.getElementById('waterLevelValue');
    elements.temperatureValue = document.getElementById('temperatureValue');
    elements.flowRateValue = document.getElementById('flowRateValue');
    elements.solarPowerValue = document.getElementById('solarPowerValue');
    
    // Power elements
    elements.solarCurrent = document.getElementById('solarCurrent');
    elements.solarDaily = document.getElementById('solarDaily');
    elements.batteryLevel = document.getElementById('batteryLevel');
    elements.batteryPercentage = document.getElementById('batteryPercentage');
    elements.batteryVoltage = document.getElementById('batteryVoltage');
    elements.batteryCurrent = document.getElementById('batteryCurrent');
    elements.generatorStatus = document.getElementById('generatorStatus');
    elements.generatorFuel = document.getElementById('generatorFuel');
    
    // Control elements
    elements.quickStartBtn = document.getElementById('quickStartBtn');
    elements.quickStopBtn = document.getElementById('quickStopBtn');
    elements.quickAutoBtn = document.getElementById('quickAutoBtn');
    elements.manualStartBtn = document.getElementById('manualStartBtn');
    elements.manualStopBtn = document.getElementById('manualStopBtn');
    elements.autoModeToggle = document.getElementById('autoModeToggle');
    
    // Lists
    elements.sensorList = document.getElementById('sensorList');
    elements.activeAlertsList = document.getElementById('activeAlertsList');
    elements.alertHistory = document.getElementById('alertHistory');
    
    // Modal elements
    elements.confirmModal = document.getElementById('confirmModal');
    elements.modalTitle = document.getElementById('modalTitle');
    elements.modalMessage = document.getElementById('modalMessage');
    elements.modalCloseBtn = document.getElementById('modalCloseBtn');
    elements.modalCancelBtn = document.getElementById('modalCancelBtn');
    elements.modalConfirmBtn = document.getElementById('modalConfirmBtn');
    
    // Loading overlay
    elements.loadingOverlay = document.getElementById('loadingOverlay');
}

function initializeEventListeners() {
    // Tab navigation
    elements.navTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.getAttribute('data-tab');
            switchTab(targetTab);
        });
    });
    
    // Pump controls
    elements.quickStartBtn?.addEventListener('click', () => startPump());
    elements.quickStopBtn?.addEventListener('click', () => stopPump());
    elements.quickAutoBtn?.addEventListener('click', () => setAutoMode());
    elements.manualStartBtn?.addEventListener('click', () => confirmAction('Start Pump', 'Are you sure you want to manually start the pump?', startPump));
    elements.manualStopBtn?.addEventListener('click', () => confirmAction('Stop Pump', 'Are you sure you want to stop the pump?', stopPump));
    
    // Auto mode toggle
    elements.autoModeToggle?.addEventListener('change', (e) => {
        appState.pumpStatus.mode = e.target.checked ? 'auto' : 'manual';
        updateUI();
    });
    
    // Power source controls
    document.querySelectorAll('.power-source').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.power-source').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            appState.powerSource = btn.getAttribute('data-source');
        });
    });
    
    // Generator controls
    document.getElementById('generatorStartBtn')?.addEventListener('click', () => {
        confirmAction('Start Generator', 'Are you sure you want to start the diesel generator?', () => {
            appState.powerData.generator.status = 'running';
            updateUI();
        });
    });
    
    document.getElementById('generatorStopBtn')?.addEventListener('click', () => {
        appState.powerData.generator.status = 'standby';
        updateUI();
    });
    
    // Modal controls
    elements.modalCloseBtn?.addEventListener('click', closeModal);
    elements.modalCancelBtn?.addEventListener('click', closeModal);
    elements.confirmModal?.addEventListener('click', (e) => {
        if (e.target === elements.confirmModal) closeModal();
    });
    
    // Alert controls
    document.getElementById('clearAlertsBtn')?.addEventListener('click', () => {
        appState.alerts = appState.alerts.filter(alert => !alert.active);
        updateUI();
    });
    
    // Email test
    document.getElementById('testEmailBtn')?.addEventListener('click', testEmail);
    
    // Report generation
    document.getElementById('generateReportBtn')?.addEventListener('click', generateReport);
    
    // Quick reports
    document.querySelectorAll('.report-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const reportType = btn.getAttribute('data-report');
            generateQuickReport(reportType);
        });
    });
    
    // Threshold settings
    document.getElementById('saveThresholdsBtn')?.addEventListener('click', saveThresholds);
}

function initializeCharts() {
    // Initialize live chart
    const liveCtx = document.getElementById('liveChart');
    if (liveCtx) {
        liveChart = new Chart(liveCtx, {
            type: 'line',
            data: {
                labels: appState.historicalData.timestamps,
                datasets: [
                    {
                        label: 'Water Level (%)',
                        data: appState.historicalData.waterLevel,
                        borderColor: '#1FB8CD',
                        backgroundColor: 'rgba(31, 184, 205, 0.1)',
                        tension: 0.4
                    },
                    {
                        label: 'Temperature (°C)',
                        data: appState.historicalData.temperature,
                        borderColor: '#FFC185',
                        backgroundColor: 'rgba(255, 193, 133, 0.1)',
                        tension: 0.4
                    },
                    {
                        label: 'Flow Rate (L/min)',
                        data: appState.historicalData.flowRate,
                        borderColor: '#B4413C',
                        backgroundColor: 'rgba(180, 65, 60, 0.1)',
                        tension: 0.4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Real-time Sensor Data'
                    },
                    legend: {
                        display: true,
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Water Level (%) / Temperature (°C)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Flow Rate (L/min)'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                }
            }
        });
    }
    
    // Initialize sensor chart
    const sensorCtx = document.getElementById('sensorChart');
    if (sensorCtx) {
        sensorChart = new Chart(sensorCtx, {
            type: 'bar',
            data: {
                labels: ['Water Level', 'Temperature', 'Flow Rate', 'pH'],
                datasets: [{
                    label: 'Current Values',
                    data: [
                        appState.sensorData.waterLevel.current,
                        appState.sensorData.temperature.current,
                        appState.sensorData.flowRate.current / 10, // Scale down for visualization
                        appState.sensorData.pH.current * 10 // Scale up for visualization
                    ],
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#5D878F']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Current Sensor Readings'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Generate initial historical data
    generateHistoricalData();
}

function generateHistoricalData() {
    const now = new Date();
    appState.historicalData.timestamps = [];
    appState.historicalData.waterLevel = [];
    appState.historicalData.temperature = [];
    appState.historicalData.flowRate = [];
    appState.historicalData.solarPower = [];
    
    for (let i = 23; i >= 0; i--) {
        const time = new Date(now.getTime() - (i * 60 * 60 * 1000));
        appState.historicalData.timestamps.push(time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
        
        // Simulate realistic variations
        appState.historicalData.waterLevel.push(Math.max(20, Math.min(90, 75 + (Math.random() - 0.5) * 10)));
        appState.historicalData.temperature.push(Math.max(20, Math.min(45, 32 + (Math.random() - 0.5) * 8)));
        appState.historicalData.flowRate.push(Math.max(100, Math.min(400, 250 + (Math.random() - 0.5) * 50)));
        
        // Solar power based on time of day
        const hour = time.getHours();
        let solarPower = 0;
        if (hour >= 6 && hour <= 18) {
            const dayProgress = (hour - 6) / 12;
            solarPower = Math.sin(dayProgress * Math.PI) * 1500 + (Math.random() - 0.5) * 200;
        }
        appState.historicalData.solarPower.push(Math.max(0, solarPower));
    }
}

function startDataSimulation() {
    // Update historical data periodically
    setInterval(() => {
        const now = new Date();
        
        // Remove oldest data point and add new one
        appState.historicalData.timestamps.shift();
        appState.historicalData.waterLevel.shift();
        appState.historicalData.temperature.shift();
        appState.historicalData.flowRate.shift();
        appState.historicalData.solarPower.shift();
        
        // Add new data point
        appState.historicalData.timestamps.push(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
        appState.historicalData.waterLevel.push(appState.sensorData.waterLevel.current);
        appState.historicalData.temperature.push(appState.sensorData.temperature.current);
        appState.historicalData.flowRate.push(appState.sensorData.flowRate.current);
        appState.historicalData.solarPower.push(appState.powerData.solar.current);
        
        // Update charts
        updateCharts();
    }, 60000); // Every minute
}

function simulateRealTimeData() {
    // Simulate sensor fluctuations
    const waterLevel = appState.sensorData.waterLevel;
    const temperature = appState.sensorData.temperature;
    const flowRate = appState.sensorData.flowRate;
    const pH = appState.sensorData.pH;
    const solar = appState.powerData.solar;
    const battery = appState.powerData.battery;
    
    // Water level changes
    waterLevel.current += (Math.random() - 0.5) * 2;
    waterLevel.current = Math.max(0, Math.min(100, waterLevel.current));
    
    // Temperature changes (daily variation)
    const hour = new Date().getHours();
    const baseTemp = 25 + Math.sin((hour - 6) / 12 * Math.PI) * 10;
    temperature.current = baseTemp + (Math.random() - 0.5) * 4;
    temperature.current = Math.max(15, Math.min(50, temperature.current));
    
    // Flow rate depends on pump status
    if (appState.pumpStatus.running) {
        flowRate.current = 240 + (Math.random() - 0.5) * 40;
    } else {
        flowRate.current = 0;
    }
    
    // pH slight variations
    pH.current += (Math.random() - 0.5) * 0.1;
    pH.current = Math.max(6.0, Math.min(9.0, pH.current));
    
    // Solar power based on time of day
    if (hour >= 6 && hour <= 18) {
        const dayProgress = (hour - 6) / 12;
        solar.current = Math.sin(dayProgress * Math.PI) * 1500 + (Math.random() - 0.5) * 200;
        solar.current = Math.max(0, solar.current);
    } else {
        solar.current = 0;
    }
    
    // Battery simulation
    if (solar.current > 500 && battery.percentage < 100) {
        battery.percentage += 0.1;
        battery.current = -Math.abs(battery.current);
        battery.status = 'charging';
    } else if (solar.current < 100 && battery.percentage > 0) {
        battery.percentage -= 0.05;
        battery.current = Math.abs(battery.current);
        battery.status = 'discharging';
    }
    battery.percentage = Math.max(0, Math.min(100, battery.percentage));
    
    // Update sensor statuses
    updateSensorStatuses();
    
    // Check for alerts
    checkAlerts();
}

function updateSensorStatuses() {
    Object.keys(appState.sensorData).forEach(key => {
        const sensor = appState.sensorData[key];
        if (sensor.threshold) {
            if (sensor.current < sensor.threshold.min || sensor.current > sensor.threshold.max) {
                sensor.status = 'warning';
            } else {
                sensor.status = 'normal';
            }
        }
    });
}

function checkAlerts() {
    const now = new Date().toISOString();
    
    // Water level alerts
    const waterLevel = appState.sensorData.waterLevel.current;
    if (waterLevel > 90) {
        addAlert('warning', 'Water level critical: ' + waterLevel.toFixed(1) + '%', now);
    } else if (waterLevel < 20) {
        addAlert('error', 'Water level low: ' + waterLevel.toFixed(1) + '%', now);
    }
    
    // Temperature alerts
    const temperature = appState.sensorData.temperature.current;
    if (temperature > 45) {
        addAlert('error', 'Temperature too high: ' + temperature.toFixed(1) + '°C', now);
    }
    
    // Battery alerts
    const batteryLevel = appState.powerData.battery.percentage;
    if (batteryLevel < 20) {
        addAlert('warning', 'Battery level low: ' + batteryLevel.toFixed(1) + '%', now);
    }
}

function addAlert(type, message, timestamp) {
    // Check if similar alert already exists
    const existingAlert = appState.alerts.find(alert => alert.message === message && alert.active);
    if (existingAlert) return;
    
    const newAlert = {
        id: Date.now(),
        type: type,
        message: message,
        timestamp: timestamp,
        active: true
    };
    
    appState.alerts.unshift(newAlert);
    
    // Limit to 50 alerts
    if (appState.alerts.length > 50) {
        appState.alerts = appState.alerts.slice(0, 50);
    }
    
    // Send email notification if configured
    if (appState.emailSettings.address && shouldSendEmailAlert(type)) {
        sendEmailAlert(newAlert);
    }
}

function shouldSendEmailAlert(type) {
    return (type === 'error' && appState.emailSettings.criticalAlerts) ||
           (type === 'warning' && appState.emailSettings.warnings) ||
           (type === 'info' && appState.emailSettings.infoMessages);
}

function sendEmailAlert(alert) {
    const templateParams = {
        to_email: appState.emailSettings.address,
        alert_type: alert.type.toUpperCase(),
        alert_message: alert.message,
        timestamp: new Date(alert.timestamp).toLocaleString(),
        system_name: 'Solar IoT Pump Monitor'
    };
    
    emailjs.send('your_service_id', 'your_template_id', templateParams)
        .then(() => {
            console.log('Alert email sent successfully');
        })
        .catch((error) => {
            console.error('Failed to send alert email:', error);
        });
}

function updateUI() {
    // Update timestamp
    updateTimestamp();
    
    // Update pump status
    updatePumpStatus();
    
    // Update metric values
    updateMetricValues();
    
    // Update power display
    updatePowerDisplay();
    
    // Update sensor list
    updateSensorList();
    
    // Update alerts
    updateAlerts();
    
    // Update charts
    updateCharts();
}

function updateTimestamp() {
    if (elements.currentTime) {
        elements.currentTime.textContent = new Date().toLocaleString();
    }
}

function updatePumpStatus() {
    if (elements.pumpStatusText) {
        const status = appState.pumpStatus;
        let statusText = status.mode.toUpperCase();
        if (status.running) {
            statusText += ' - RUNNING';
        } else {
            statusText += ' - STOPPED';
        }
        elements.pumpStatusText.textContent = statusText;
        
        // Update status dot color
        const statusDot = document.querySelector('.status-dot');
        if (statusDot) {
            statusDot.className = 'status-dot';
            if (status.running) {
                statusDot.classList.add('status--success');
            } else {
                statusDot.classList.add('status--error');
            }
        }
    }
    
    if (elements.pumpUptime) {
        elements.pumpUptime.textContent = appState.pumpStatus.uptime;
    }
    
    if (elements.pumpTotalRuntime) {
        elements.pumpTotalRuntime.textContent = appState.pumpStatus.totalRuntime;
    }
}

function updateMetricValues() {
    if (elements.waterLevelValue) {
        elements.waterLevelValue.textContent = appState.sensorData.waterLevel.current.toFixed(1) + '%';
    }
    
    if (elements.temperatureValue) {
        elements.temperatureValue.textContent = appState.sensorData.temperature.current.toFixed(1) + '°C';
    }
    
    if (elements.flowRateValue) {
        elements.flowRateValue.textContent = appState.sensorData.flowRate.current.toFixed(0) + ' L/min';
    }
    
    if (elements.solarPowerValue) {
        elements.solarPowerValue.textContent = appState.powerData.solar.current.toFixed(0) + 'W';
    }
}

function updatePowerDisplay() {
    if (elements.solarCurrent) {
        elements.solarCurrent.textContent = appState.powerData.solar.current.toFixed(0) + 'W';
    }
    
    if (elements.solarDaily) {
        elements.solarDaily.textContent = (appState.powerData.solar.daily / 1000).toFixed(1) + ' kWh';
    }
    
    if (elements.batteryLevel) {
        elements.batteryLevel.style.width = appState.powerData.battery.percentage + '%';
    }
    
    if (elements.batteryPercentage) {
        elements.batteryPercentage.textContent = appState.powerData.battery.percentage.toFixed(0) + '%';
    }
    
    if (elements.batteryVoltage) {
        elements.batteryVoltage.textContent = appState.powerData.battery.voltage.toFixed(1) + 'V';
    }
    
    if (elements.batteryCurrent) {
        elements.batteryCurrent.textContent = appState.powerData.battery.current.toFixed(1) + 'A';
    }
    
    if (elements.generatorStatus) {
        elements.generatorStatus.textContent = appState.powerData.generator.status.charAt(0).toUpperCase() + 
                                               appState.powerData.generator.status.slice(1);
    }
    
    if (elements.generatorFuel) {
        elements.generatorFuel.textContent = appState.powerData.generator.fuelLevel + '%';
    }
}

function updateSensorList() {
    if (!elements.sensorList) return;
    
    const sensors = [
        { key: 'waterLevel', icon: '💧', name: 'Water Level', unit: '%' },
        { key: 'temperature', icon: '🌡️', name: 'Temperature', unit: '°C' },
        { key: 'flowRate', icon: '🌊', name: 'Flow Rate', unit: 'L/min' },
        { key: 'pH', icon: '🧪', name: 'pH Level', unit: 'pH' },
        { key: 'rainSensor', icon: '🌧️', name: 'Rain Sensor', unit: '' }
    ];
    
    elements.sensorList.innerHTML = sensors.map(sensor => {
        const data = appState.sensorData[sensor.key];
        let value = sensor.key === 'rainSensor' ? (data.current ? 'Detected' : 'Clear') : 
                   data.current.toFixed(sensor.key === 'pH' ? 1 : 0);
        let statusClass = data.status === 'normal' ? 'status--success' : 
                         data.status === 'warning' ? 'status--warning' : 'status--error';
        
        return `
            <div class="sensor-item">
                <div class="sensor-info">
                    <div class="sensor-icon">${sensor.icon}</div>
                    <div class="sensor-details">
                        <h4>${sensor.name}</h4>
                        <p>Status: <span class="status ${statusClass}">${data.status}</span></p>
                    </div>
                </div>
                <div class="sensor-value">
                    <div class="sensor-reading">${value}${sensor.unit}</div>
                    <div class="sensor-status ${statusClass}">●</div>
                </div>
            </div>
        `;
    }).join('');
}

function updateAlerts() {
    if (!elements.activeAlertsList) return;
    
    const activeAlerts = appState.alerts.filter(alert => alert.active);
    
    if (activeAlerts.length === 0) {
        elements.activeAlertsList.innerHTML = '<p class="no-alerts">No active alerts</p>';
        return;
    }
    
    elements.activeAlertsList.innerHTML = activeAlerts.map(alert => {
        const icon = alert.type === 'error' ? '🚨' : 
                    alert.type === 'warning' ? '⚠️' : 'ℹ️';
        
        return `
            <div class="alert-item ${alert.type}">
                <div class="alert-icon">${icon}</div>
                <div class="alert-content">
                    <div class="alert-message">${alert.message}</div>
                    <div class="alert-timestamp">${new Date(alert.timestamp).toLocaleString()}</div>
                </div>
            </div>
        `;
    }).join('');
    
    // Update alert history
    if (elements.alertHistory) {
        elements.alertHistory.innerHTML = appState.alerts.slice(0, 20).map(alert => {
            const icon = alert.type === 'error' ? '🚨' : 
                        alert.type === 'warning' ? '⚠️' : 'ℹ️';
            const statusText = alert.active ? 'Active' : 'Resolved';
            
            return `
                <div class="alert-item ${alert.type}">
                    <div class="alert-icon">${icon}</div>
                    <div class="alert-content">
                        <div class="alert-message">${alert.message}</div>
                        <div class="alert-timestamp">${new Date(alert.timestamp).toLocaleString()} - ${statusText}</div>
                    </div>
                </div>
            `;
        }).join('');
    }
}

function updateCharts() {
    if (liveChart) {
        liveChart.data.labels = appState.historicalData.timestamps;
        liveChart.data.datasets[0].data = appState.historicalData.waterLevel;
        liveChart.data.datasets[1].data = appState.historicalData.temperature;
        liveChart.data.datasets[2].data = appState.historicalData.flowRate;
        liveChart.update('none');
    }
    
    if (sensorChart) {
        sensorChart.data.datasets[0].data = [
            appState.sensorData.waterLevel.current,
            appState.sensorData.temperature.current,
            appState.sensorData.flowRate.current / 10,
            appState.sensorData.pH.current * 10
        ];
        sensorChart.update('none');
    }
}

function switchTab(tabName) {
    // Update active tab
    elements.navTabs.forEach(tab => {
        tab.classList.remove('active');
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('active');
        }
    });
    
    // Update tab content
    elements.tabContents.forEach(content => {
        content.classList.remove('active');
        if (content.id === tabName) {
            content.classList.add('active');
        }
    });
    
    appState.activeTab = tabName;
}

function startPump() {
    appState.pumpStatus.running = true;
    appState.pumpStatus.mode = 'manual';
    updateUI();
}

function stopPump() {
    appState.pumpStatus.running = false;
    appState.pumpStatus.mode = 'manual';
    updateUI();
}

function setAutoMode() {
    appState.pumpStatus.mode = 'auto';
    // Auto logic: start pump if water level is low, stop if high
    if (appState.sensorData.waterLevel.current < 30) {
        appState.pumpStatus.running = true;
    } else if (appState.sensorData.waterLevel.current > 85) {
        appState.pumpStatus.running = false;
    }
    updateUI();
}

function confirmAction(title, message, callback) {
    elements.modalTitle.textContent = title;
    elements.modalMessage.textContent = message;
    elements.confirmModal.classList.remove('hidden');
    
    // Remove previous event listeners
    elements.modalConfirmBtn.replaceWith(elements.modalConfirmBtn.cloneNode(true));
    elements.modalConfirmBtn = document.getElementById('modalConfirmBtn');
    
    elements.modalConfirmBtn.addEventListener('click', () => {
        callback();
        closeModal();
    });
}

function closeModal() {
    elements.confirmModal.classList.add('hidden');
}

function showLoading() {
    elements.loadingOverlay.classList.remove('hidden');
}

function hideLoading() {
    elements.loadingOverlay.classList.add('hidden');
}

function testEmail() {
    const emailInput = document.getElementById('alertEmail');
    if (!emailInput.value) {
        alert('Please enter an email address first.');
        return;
    }
    
    showLoading();
    
    const templateParams = {
        to_email: emailInput.value,
        alert_type: 'TEST',
        alert_message: 'This is a test email from your Solar IoT Pump Monitor system.',
        timestamp: new Date().toLocaleString(),
        system_name: 'Solar IoT Pump Monitor'
    };
    
    emailjs.send('your_service_id', 'your_template_id', templateParams)
        .then(() => {
            hideLoading();
            alert('Test email sent successfully!');
            appState.emailSettings.address = emailInput.value;
        })
        .catch((error) => {
            hideLoading();
            console.error('Failed to send test email:', error);
            alert('Failed to send test email. Please check your configuration.');
        });
}

function generateReport() {
    showLoading();
    
    setTimeout(() => {
        const reportType = document.getElementById('reportType').value;
        const startDate = document.getElementById('reportStartDate').value;
        const endDate = document.getElementById('reportEndDate').value;
        
        createPDFReport(reportType, startDate, endDate);
        hideLoading();
    }, 1000);
}

function generateQuickReport(type) {
    showLoading();
    
    setTimeout(() => {
        createPDFReport(type);
        hideLoading();
    }, 500);
}

function createPDFReport(reportType, startDate = null, endDate = null) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(20);
    doc.setTextColor(31, 184, 205);
    doc.text('Solar IoT Pump Monitor', 20, 20);
    doc.setFontSize(16);
    doc.setTextColor(0, 0, 0);
    doc.text(`${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report`, 20, 30);
    
    // Date range
    const dateRange = startDate && endDate ? 
        `${startDate} to ${endDate}` : 
        `Generated on ${new Date().toLocaleDateString()}`;
    doc.setFontSize(12);
    doc.setTextColor(100, 100, 100);
    doc.text(dateRange, 20, 40);
    
    let yPos = 60;
    
    // Current system status
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text('Current System Status', 20, yPos);
    yPos += 10;
    
    doc.setFontSize(10);
    doc.text(`Pump Status: ${appState.pumpStatus.mode.toUpperCase()} - ${appState.pumpStatus.running ? 'RUNNING' : 'STOPPED'}`, 20, yPos);
    yPos += 8;
    doc.text(`Water Level: ${appState.sensorData.waterLevel.current.toFixed(1)}%`, 20, yPos);
    yPos += 8;
    doc.text(`Temperature: ${appState.sensorData.temperature.current.toFixed(1)}°C`, 20, yPos);
    yPos += 8;
    doc.text(`Flow Rate: ${appState.sensorData.flowRate.current.toFixed(0)} L/min`, 20, yPos);
    yPos += 8;
    doc.text(`pH Level: ${appState.sensorData.pH.current.toFixed(1)}`, 20, yPos);
    yPos += 8;
    doc.text(`Solar Power: ${appState.powerData.solar.current.toFixed(0)}W`, 20, yPos);
    yPos += 8;
    doc.text(`Battery Level: ${appState.powerData.battery.percentage.toFixed(0)}%`, 20, yPos);
    yPos += 20;
    
    // Recent alerts
    doc.setFontSize(14);
    doc.text('Recent Alerts', 20, yPos);
    yPos += 10;
    
    const recentAlerts = appState.alerts.slice(0, 10);
    if (recentAlerts.length === 0) {
        doc.setFontSize(10);
        doc.text('No recent alerts', 20, yPos);
    } else {
        recentAlerts.forEach(alert => {
            if (yPos > 280) {
                doc.addPage();
                yPos = 20;
            }
            doc.setFontSize(10);
            doc.text(`${alert.type.toUpperCase()}: ${alert.message}`, 20, yPos);
            yPos += 6;
            doc.setFontSize(8);
            doc.setTextColor(100, 100, 100);
            doc.text(new Date(alert.timestamp).toLocaleString(), 20, yPos);
            doc.setTextColor(0, 0, 0);
            yPos += 10;
        });
    }
    
    // Performance summary
    if (yPos > 250) {
        doc.addPage();
        yPos = 20;
    }
    
    yPos += 10;
    doc.setFontSize(14);
    doc.text('Performance Summary (Last 24 Hours)', 20, yPos);
    yPos += 15;
    
    const avgWaterLevel = appState.historicalData.waterLevel.reduce((a, b) => a + b, 0) / appState.historicalData.waterLevel.length;
    const avgTemperature = appState.historicalData.temperature.reduce((a, b) => a + b, 0) / appState.historicalData.temperature.length;
    const avgFlowRate = appState.historicalData.flowRate.reduce((a, b) => a + b, 0) / appState.historicalData.flowRate.length;
    const totalSolarEnergy = appState.historicalData.solarPower.reduce((a, b) => a + b, 0) / 1000; // Convert to kWh
    
    doc.setFontSize(10);
    doc.text(`Average Water Level: ${avgWaterLevel.toFixed(1)}%`, 20, yPos);
    yPos += 8;
    doc.text(`Average Temperature: ${avgTemperature.toFixed(1)}°C`, 20, yPos);
    yPos += 8;
    doc.text(`Average Flow Rate: ${avgFlowRate.toFixed(0)} L/min`, 20, yPos);
    yPos += 8;
    doc.text(`Total Solar Energy: ${totalSolarEnergy.toFixed(2)} kWh`, 20, yPos);
    yPos += 8;
    doc.text(`System Uptime: ${appState.pumpStatus.uptime}`, 20, yPos);
    yPos += 8;
    doc.text(`Total Runtime: ${appState.pumpStatus.totalRuntime}`, 20, yPos);
    
    // Save the PDF
    const filename = `solar-pump-report-${reportType}-${new Date().toISOString().split('T')[0]}.pdf`;
    doc.save(filename);
}

function saveThresholds() {
    const waterStart = document.getElementById('waterStartThreshold').value;
    const waterStop = document.getElementById('waterStopThreshold').value;
    const tempLimit = document.getElementById('tempThreshold').value;
    
    appState.sensorData.waterLevel.threshold.min = parseInt(waterStart);
    appState.sensorData.waterLevel.threshold.max = parseInt(waterStop);
    appState.sensorData.temperature.threshold.max = parseInt(tempLimit);
    
    alert('Threshold settings saved successfully!');
}